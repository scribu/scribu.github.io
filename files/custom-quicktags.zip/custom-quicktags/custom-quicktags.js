edButtons[edButtons.length] = new edButton( 'sup', 'sup', '<sup>', '</sup>', '' );

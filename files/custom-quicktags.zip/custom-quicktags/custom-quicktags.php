<?php
/*
Plugin Name: Custom Quicktags
Version: 1.0
Author: scribu
*/

function my_custom_quicktags() {
	wp_enqueue_script(
		'my_custom_quicktags',
		plugin_dir_url( __FILE__ ) . 'custom-quicktags.js',
		array( 'quicktags' )
	);
}
add_action( 'admin_print_scripts', 'my_custom_quicktags' );

